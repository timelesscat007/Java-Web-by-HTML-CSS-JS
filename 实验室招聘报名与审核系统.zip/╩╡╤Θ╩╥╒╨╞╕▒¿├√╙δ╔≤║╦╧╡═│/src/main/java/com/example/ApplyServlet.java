package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(name = "ApplyServlet", urlPatterns = {"/apply"})
public class ApplyServlet extends HttpServlet {
    private static final String APPLICATION_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\application.json";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 读取请求体中的 JSON 数据
        BufferedReader reader = request.getReader();
        StringBuilder json = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            json.append(line);
        }

        // 读取现有的 JSON 数据
        JSONArray applications;
        if (Files.exists(Paths.get(APPLICATION_FILE))) {
            try (FileReader fileReader = new FileReader(APPLICATION_FILE)) {
                StringBuilder fileContent = new StringBuilder();
                int ch;
                while ((ch = fileReader.read()) != -1) {
                    fileContent.append((char) ch);
                }
                applications = new JSONArray(fileContent.toString());
            } catch (Exception e) {
                applications = new JSONArray();
            }
        } else {
            applications = new JSONArray();
        }

        // 将新的申请数据添加到 JSON 数组中
        applications.put(new JSONObject(json.toString()));

        // 将更新后的 JSON 数组写回到文件
        try (FileWriter fileWriter = new FileWriter(APPLICATION_FILE)) {
            fileWriter.write(applications.toString(4)); // 使用4个空格缩进格式化输出
        }

        // 设置响应类型为 JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("{\"message\": \"申请表提交成功\"}");
    }
}
