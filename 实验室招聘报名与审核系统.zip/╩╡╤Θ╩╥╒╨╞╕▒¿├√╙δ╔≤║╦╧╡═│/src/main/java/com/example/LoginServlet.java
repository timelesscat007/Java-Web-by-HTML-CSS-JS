package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import org.json.JSONObject;

@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        StringBuilder json = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            json.append(line);
        }
        String jsonString = json.toString();

        // 使用org.json库解析JSON字符串
        JSONObject jsonObject = new JSONObject(jsonString);

        // 获取并验证id和password
        String username = jsonObject.getString("username");
        String password = jsonObject.getString("password");
        if ("DZJ".equals(username) && "2022217503".equals(password)) {
            response.getWriter().write("{\"success\": true}");
        } else {

            response.getWriter().write("{\"success\": false}");
        }
    }
}
