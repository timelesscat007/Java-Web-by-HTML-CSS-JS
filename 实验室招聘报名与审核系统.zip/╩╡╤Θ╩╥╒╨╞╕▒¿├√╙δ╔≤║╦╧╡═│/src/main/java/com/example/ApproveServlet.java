//package com.example;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.*;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.nio.file.StandardOpenOption;
//import java.util.List;
//import java.util.stream.Collectors;
//
//@WebServlet(name = "ApproveServlet", urlPatterns = {"/approve"})
//public class ApproveServlet extends HttpServlet {
//    private static final String APPLICATION_FILE = "D:\\java学习\\GPTTEST\\src\\main\\resources\\application.json";
//    private static final String APPROVE_FILE = "D:\\java学习\\GPTTEST\\src\\main\\resources\\approve.txt";
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        BufferedReader reader = request.getReader();
//        StringBuilder json = new StringBuilder();
//        String line;
//        while ((line = reader.readLine()) != null) {
//            json.append(line);
//        }
//        System.out.println("json"+json);
//        String email = json.toString().replace("{\"email\":\"", "").replace("\"}", "");
//
//        List<String> applications = Files.readAllLines(Paths.get(APPLICATION_FILE));
//        List<String> approvedApplications = applications.stream()
//                .filter(app -> app.contains("\"email\":\"" + email + "\""))
//                .collect(Collectors.toList());
//        if (!approvedApplications.isEmpty()) {
//            String approvedApplication = approvedApplications.get(0);
//            Files.write(Paths.get(APPROVE_FILE), (approvedApplication + System.lineSeparator()).getBytes(), StandardOpenOption.APPEND);
//            applications.remove(approvedApplication);
//            Files.write(Paths.get(APPLICATION_FILE), applications);
//
//            response.getWriter().write("{\"message\": \"Application approved\"}");
//        } else {
//            response.getWriter().write("{\"message\": \"Application not found\"}");
//        }
//    }
//}
package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(name = "ApproveServlet", urlPatterns = {"/approve"})
public class ApproveServlet extends HttpServlet {
    private static final String APPLICATION_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\application.json";
    private static final String APPROVE_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\approve.txt";
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        StringBuilder json = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            json.append(line);
        }
        String email = json.toString().replace("{\"email\":\"", "").replace("\"}", "");
        StringBuilder fileContent = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(APPLICATION_FILE))) {
            String fileLine;
            while ((fileLine = br.readLine()) != null) {
                fileContent.append(fileLine);
            }
        }

        JSONArray applications = new JSONArray(fileContent.toString());
        List<JSONObject> approvedApplications = new ArrayList<>();

        for (int i = 0; i < applications.length(); i++) {
            JSONObject application = applications.getJSONObject(i);
            if (application.getString("email").equals(email)) {
                approvedApplications.add(application);
                break;
            }
        }
        if (!approvedApplications.isEmpty()) {
            JSONObject approvedApplication = approvedApplications.get(0);

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(APPROVE_FILE, true))) {
                bw.write(approvedApplication.toString());
                bw.newLine();
            }
            JSONArray newApplications = new JSONArray();
            for (int i = 0; i < applications.length(); i++) {
                JSONObject application = applications.getJSONObject(i);
                if (!application.getString("email").equals(email)) {
                    newApplications.put(application);
                }
            }
            Files.write(Paths.get(APPLICATION_FILE), newApplications.toString().getBytes());

            response.getWriter().write("{\"message\": \"通过\"}");
        } else {
            response.getWriter().write("{\"message\": \"Application not found\"}");
        }
    }
}
