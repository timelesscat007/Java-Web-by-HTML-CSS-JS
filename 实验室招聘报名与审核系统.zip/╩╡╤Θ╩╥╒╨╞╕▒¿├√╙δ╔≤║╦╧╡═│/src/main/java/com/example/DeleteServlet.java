package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet(name = "DeleteServlet", urlPatterns = {"/delete"})
public class DeleteServlet extends HttpServlet {
    private static final String REJECT_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\reject.txt";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        StringBuilder json = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            json.append(line);
        }
        String email = json.toString().replace("{\"email\":\"", "").replace("\"}", "");

        List<String> rejectedApplications = Files.readAllLines(Paths.get(REJECT_FILE));
        List<String> matchedRejectedApplications = rejectedApplications.stream()
                .filter(app -> app.contains("\"email\":\"" + email + "\""))
                .collect(Collectors.toList());

        if (!matchedRejectedApplications.isEmpty()) {
            String rejectedApplication = matchedRejectedApplications.get(0);
            rejectedApplications.remove(rejectedApplication);
            Files.write(Paths.get(REJECT_FILE), rejectedApplications);

            response.getWriter().write("{\"message\": \"删除成功\"}");
        } else {
            response.getWriter().write("{\"message\": \"未找到对应的被拒绝申请\"}");
        }
    }
}
