package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.stream.Collectors;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(name = "WithdrawApproveServlet", urlPatterns = {"/withdraw_approve"})
public class WithdrawApproveServlet extends HttpServlet {
    private static final String APPLICATION_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\application.json";
    private static final String APPROVE_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\approve.txt";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        StringBuilder json = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            json.append(line);
        }
        String email = json.toString().replace("{\"email\":\"", "").replace("\"}", "");

        List<String> approvedApplications = Files.readAllLines(Paths.get(APPROVE_FILE));
        List<String> matchedApprovedApplications = approvedApplications.stream()
                .filter(app -> app.contains("\"email\":\"" + email + "\""))
                .collect(Collectors.toList());

        if (!matchedApprovedApplications.isEmpty()) {
            String approvedApplication = matchedApprovedApplications.get(0);
            approvedApplications.remove(approvedApplication);
            Files.write(Paths.get(APPROVE_FILE), approvedApplications);

            JSONArray applications;
            if (Files.exists(Paths.get(APPLICATION_FILE))) {
                StringBuilder fileContent = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new FileReader(APPLICATION_FILE))) {
                    String fileLine;
                    while ((fileLine = br.readLine()) != null) {
                        fileContent.append(fileLine);
                    }
                }
                applications = new JSONArray(fileContent.toString());
            } else {
                applications = new JSONArray();
            }

            applications.put(new JSONObject(approvedApplication));
            Files.write(Paths.get(APPLICATION_FILE), applications.toString().getBytes(), StandardOpenOption.CREATE);

            response.getWriter().write("{\"message\": \"撤销通过成功\"}");
        } else {
            response.getWriter().write("{\"message\": \"未找到对应的已通过申请\"}");
        }
    }
}