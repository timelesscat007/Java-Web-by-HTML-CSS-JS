package com.example;

import org.json.JSONArray;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.BufferedReader;

@WebServlet(name = "ReviewServlet", urlPatterns = {"/review"})
public class ReviewServlet extends HttpServlet {
    private static final String APPLICATION_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\application.json";
    private static final String REJECT_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\reject.txt";
    private static final String APPROVE_FILE = "D:\\java学习\\实验室招聘报名与审核系统\\src\\main\\resources\\approve.txt";
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置响应类型为 JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // 读取现有的 JSON 数据,为待审核申请表
        JSONArray applications = null;
        if (Files.exists(Paths.get(APPLICATION_FILE))) {
            try (FileReader fileReader = new FileReader(APPLICATION_FILE)) {
                StringBuilder fileContent = new StringBuilder();
                int ch;
                while ((ch = fileReader.read()) != -1) {
                    fileContent.append((char) ch);
                }
                applications = new JSONArray(fileContent.toString());
            } catch (Exception e) {
                applications = new JSONArray();
            }
        } else {
            applications = new JSONArray();
        }

        if (applications.isEmpty()) {
            response.getWriter().write("{\"applications\": [], ");
        }
        else {
            response.getWriter().write("{\"applications\": "+applications+", ");
        }
        //读未通过的文件
        Path Reject_filePath = Paths.get(REJECT_FILE);
        String reject_string = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(Reject_filePath.toFile()))) {
            String line1;
            boolean flag = false;
            while ((line1 = reader.readLine()) != null) {
                // 处理每一行
                if (!flag){
                    reject_string = line1;
                    flag = true;
                }
                else {
                    reject_string = reject_string + "," + line1;
                }
            }
            if (reject_string.equals("")) response.getWriter().write("\"rejects\": [], ");
            else response.getWriter().write("\"rejects\": ["+reject_string+"], ");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //读已经通过的文件
        Path Approve_filePath = Paths.get(APPROVE_FILE);
        String approve_string = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(Approve_filePath.toFile()))) {
            String line2;
            boolean flag = false;
            while ((line2 = reader.readLine()) != null) {
                // 处理每一行
                if (!flag){
                    approve_string = line2;
                    flag = true;
                }
                else {
                    approve_string = approve_string + "," + line2;
                }
            }
            if (approve_string.equals("")) response.getWriter().write("\"approves\": []}");
            else response.getWriter().write("\"approves\": ["+approve_string+"]}");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
