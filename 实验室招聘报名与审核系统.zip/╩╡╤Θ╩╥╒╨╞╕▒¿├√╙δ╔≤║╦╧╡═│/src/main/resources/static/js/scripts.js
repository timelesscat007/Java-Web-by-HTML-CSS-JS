document.addEventListener('DOMContentLoaded', function() {
    const applyForm = document.getElementById('applyForm');
    if (applyForm) {
        applyForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(applyForm);
            fetch('/apply', {
                method: 'POST',
                body: JSON.stringify(Object.fromEntries(formData)),
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(response => response.json())
                .then(data => {
                    alert(data.message);
                    applyForm.reset();
                });
        });
    }

    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(loginForm);
            fetch('/login', {
                method: 'POST',
                body: JSON.stringify(Object.fromEntries(formData)),
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = 'review.html';
                    } else {
                        alert('密码错误，登录失败');
                    }
                });
        });
    }

    if (window.location.pathname.endsWith('review.html')) {
        fetch('/review')
            .then(response => response.json())
            .then(data => {
                //显示未通过申请表
                const rejectsDiv = document.getElementById('rejects');
                if (data.rejects.length === 0) {
                    const rejectDiv = document.createElement('div');
                    rejectDiv.className = 'reject';
                    rejectDiv.innerHTML = `
                    <div class="container-text">
                    <div class="box_1">
                         <h1>暂无</h1>
                    </div>
                    </div>
                    `;//container-text待设计
                    rejectsDiv.appendChild(rejectDiv);
                }
                else {
                    data.rejects.forEach(reject => {
                        const rejectDiv = document.createElement('div');
                        rejectDiv.className = 'reject';
                        rejectDiv.innerHTML = `
                    <div class="container-text">
                    <div class="box_1">
                         <div class="section">
                            <p>姓名: ${reject.name}</p>
                            <p>性别: ${reject.gender}</p>
                            <p>专业: ${reject.major}</p>
                            <p>电子邮箱: ${reject.email}</p>
                            <p>简历: ${reject.resume}</p>
                            <button onclick="withdraw_rejectApplication('${reject.email}')">撤回</button>
                            <button onclick="delete_rejectApplication('${reject.email}')">删除</button>
                        </div>
                    </div>
                    </div>
                    `;
                        rejectsDiv.appendChild(rejectDiv);
                    });
                }

                //显示待审核申请表
                const applicationsDiv = document.getElementById('applications');
                if (data.applications.length === 0) {
                    const applicationDiv = document.createElement('div');
                    applicationDiv.className = 'application';
                    applicationDiv.innerHTML = `
                    <div class="container-text">
                    <div class="box_1">
                         <h1>暂无</h1>
                    </div>
                    </div>
                    `;//待设计
                    applicationsDiv.appendChild(applicationDiv);
                }
                else {
                    data.applications.forEach(application => {
                        const applicationDiv = document.createElement('div');
                        applicationDiv.className = 'application';
                        applicationDiv.innerHTML = `
                    <div class="container-text">
                    <div class="box_1">
                         <div class="section">
                            <p>姓名: ${application.name}</p>
                            <p>性别: ${application.gender}</p>
                            <p>专业: ${application.major}</p>
                            <p>电子邮箱: ${application.email}</p>
                            <p>简历: ${application.resume}</p>
                            <button onclick="approveApplication('${application.email}')">通过</button>
                            <button onclick="rejectApplication('${application.email}')">拒绝</button>
                        </div>
                    </div>
                    </div>
                    `;
                        applicationsDiv.appendChild(applicationDiv);
                    });
                }

                //显示已通过申请表
                const approvesDiv = document.getElementById('approves');
                if (data.approves.length === 0) {
                    const approveDiv = document.createElement('div');
                    approveDiv.className = 'approve';
                    approveDiv.innerHTML = `
                    <div class="container-text">
                    <div class="box_1">
                         <h1>暂无</h1>
                    </div>
                    </div>
                    `;//container-text待设计
                    approvesDiv.appendChild(approveDiv);
                }
                else {
                    data.approves.forEach(approve => {
                        const approveDiv = document.createElement('div');
                        approveDiv.className = 'approve';
                        approveDiv.innerHTML = `
                    <div class="container-text">
                    <div class="box_1">
                         <div class="section">
                            <p>姓名: ${approve.name}</p>
                            <p>性别: ${approve.gender}</p>
                            <p>专业: ${approve.major}</p>
                            <p>电子邮箱: ${approve.email}</p>
                            <p>简历: ${approve.resume}</p>
                            <button onclick="withdraw_approveApplication('${approve.email}')">撤回</button>
                        </div>
                    </div>
                    </div>
                    `;
                        approvesDiv.appendChild(approveDiv);
                    });
                }

            });
    }
});
function approveApplication(email) {
    fetch('/approve', {
        method: 'POST',
        body: JSON.stringify({ email }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.json())
        .then(data => {
            location.reload();
        });
}
function rejectApplication(email)  {
    fetch('/reject', {
        method: 'POST',
        body: JSON.stringify({ email }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.json())
        .then(data => {
            location.reload();
        });
}

function withdraw_approveApplication(email)  {//未设计
    fetch('/withdraw_approve', {
        method: 'POST',
        body: JSON.stringify({ email }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.json())
        .then(data => {
            location.reload();
        });
}

function withdraw_rejectApplication(email)  {
    fetch('/withdraw_reject', {
        method: 'POST',
        body: JSON.stringify({ email }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.json())
        .then(data => {
            location.reload();
        });
}
function delete_rejectApplication(email)  {
    fetch('/delete', {
        method: 'POST',
        body: JSON.stringify({ email }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.json())
        .then(data => {
            location.reload();
        });
}
